mkdir data
cd data
wget https://huggingface.co/runwayml/stable-diffusion-v1-5/resolve/main/v1-5-pruned.ckpt
wget https://huggingface.co/runwayml/stable-diffusion-v1-5/resolve/main/tokenizer/vocab.json
wget https://huggingface.co/runwayml/stable-diffusion-v1-5/resolve/main/tokenizer/merges.txt 